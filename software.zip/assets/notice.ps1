﻿# ---------- 0. 高 DPI 感知（必须最先执行） ----------
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class DpiHelper {
    [DllImport("shcore.dll")]
    public static extern int SetProcessDpiAwareness(int value);
}
"@
try { [DpiHelper]::SetProcessDpiAwareness(2) | Out-Null } catch {}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# 开启 ClearType 文本渲染
[System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)
[System.Windows.Forms.Application]::EnableVisualStyles()

# ---------- 配置 ----------
$Title      = "2901 Island"
$Content    = "您是否希望把 2901 Island 添加到桌面快捷方式？"
$ExeName    = "2901island.exe"
$TimeoutSec = 60

# 【核心修改】获取父目录来找 exe
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ParentDir = Split-Path -Parent $ScriptDir
$ExePath   = Join-Path $ParentDir $ExeName

$Desktop   = [Environment]::GetFolderPath("Desktop")
$LnkPath   = Join-Path $Desktop "2901 Island.lnk"

# ---------- 按 DPI 缩放的基础单位 ----------
$dpi = [System.Drawing.Graphics]::FromHwnd([IntPtr]::Zero).DpiX
if (-not $dpi -or $dpi -le 0) { $dpi = 96 }
$scale = $dpi / 96.0

function S([double]$v) { [int][Math]::Round($v * $scale) }

# ---------- timer 先声明 ----------
$script:remaining = $TimeoutSec
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 1000

# ---------- 窗口 ----------
$form = New-Object System.Windows.Forms.Form
$form.Text = $Title
$form.ClientSize = New-Object System.Drawing.Size((S 400), (S 170))
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.TopMost = $true
$form.BackColor = [System.Drawing.Color]::White
$form.Font = New-Object System.Drawing.Font("Segoe UI", 9)   # Win11 默认 UI 字体

# ---------- 图标：矢量绘制（不模糊） ----------
$iconBox = New-Object System.Windows.Forms.PictureBox
$iconBox.Location = New-Object System.Drawing.Point((S 20), (S 22))
$iconBox.Size = New-Object System.Drawing.Size((S 36), (S 36))
$iconBox.BackColor = [System.Drawing.Color]::Transparent
$iconBox.Add_Paint({
    param($s, $e)
    $g = $e.Graphics
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::ClearTypeGridFit

    $size = (S 32)
    $cx = $size / 2.0
    $cy = $size / 2.0
    $r  = $size / 2.0 - 1

    # 蓝色圆形
    $brush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(0, 120, 215))
    $g.FillEllipse($brush, 0, 0, $size, $size)
    $brush.Dispose()

    # 白色 "i"
    $font = New-Object System.Drawing.Font("Segoe UI", ($size * 0.55), [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
    $fmt = New-Object System.Drawing.StringFormat
    $fmt.Alignment = [System.Drawing.StringAlignment]::Center
    $fmt.LineAlignment = [System.Drawing.StringAlignment]::Center
    $rect = New-Object System.Drawing.RectangleF(0, 0, $size, $size)
    $g.DrawString("i", $font, [System.Drawing.Brushes]::White, $rect, $fmt)
    $font.Dispose()
})
$form.Controls.Add($iconBox)

# ---------- 标题 ----------
$titleLabel = New-Object System.Windows.Forms.Label
$titleLabel.Text = $Title
$titleLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 11)
$titleLabel.Location = New-Object System.Drawing.Point((S 68), (S 20))
$titleLabel.AutoSize = $true
$form.Controls.Add($titleLabel)

# ---------- 内容 ----------
$contentLabel = New-Object System.Windows.Forms.Label
$contentLabel.Text = $Content
$contentLabel.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$contentLabel.ForeColor = [System.Drawing.Color]::FromArgb(60, 60, 60)
$contentLabel.Location = New-Object System.Drawing.Point((S 68), (S 50))
$contentLabel.Size = New-Object System.Drawing.Size((S 310), (S 50))
$form.Controls.Add($contentLabel)

# ---------- 倒计时 ----------
$countLabel = New-Object System.Windows.Forms.Label
$countLabel.Text = "$TimeoutSec 秒后自动关闭"
$countLabel.Font = New-Object System.Drawing.Font("Segoe UI", 8)
$countLabel.ForeColor = [System.Drawing.Color]::Gray
$countLabel.Location = New-Object System.Drawing.Point((S 270), (S 95))
$countLabel.AutoSize = $true
$form.Controls.Add($countLabel)

# ---------- 按钮样式 ----------
function New-FlatButton([string]$text, [int]$x, [int]$y) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text
    $b.Location = New-Object System.Drawing.Point($x, $y)
    $b.Size = New-Object System.Drawing.Size((S 90), (S 30))
    $b.FlatStyle = [System.Windows.Forms.FlatStyle]::System
    $b.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    return $b
}

# 是的
$btnYes = New-FlatButton "是的" (S 180) (S 125)
$btnYes.Add_Click({
    $timer.Stop()
    if (-not (Test-Path $ExePath)) {
        [System.Windows.Forms.MessageBox]::Show("找不到文件：$ExePath", "错误", "OK", "Error") | Out-Null
        $form.Close(); return
    }
    $ws = New-Object -ComObject WScript.Shell
    $sc = $ws.CreateShortcut($LnkPath)
    $sc.TargetPath       = $ExePath
    $sc.WorkingDirectory = $ParentDir
    $sc.IconLocation     = $ExePath
    $sc.Description      = "2901 Island"
    $sc.Save()
    $form.Close()
})
$form.Controls.Add($btnYes)

# 算了
$btnNo = New-FlatButton "算了" (S 280) (S 125)
$btnNo.Add_Click({ $timer.Stop(); $form.Close() })
$form.Controls.Add($btnNo)

# ---------- 定时器 ----------
$timer.Add_Tick({
    $script:remaining--
    if ($script:remaining -le 0) { $timer.Stop(); $form.Close() }
    else { $countLabel.Text = "$($script:remaining) 秒后自动关闭" }
})
$timer.Start()

# ---------- 显示并播放系统提示音 ----------
[System.Media.SystemSounds]::Asterisk.Play()
[void]$form.ShowDialog()
$timer.Dispose()